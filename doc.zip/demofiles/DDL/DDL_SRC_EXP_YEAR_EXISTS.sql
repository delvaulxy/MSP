CREATE TABLE SRC_EXP_YEAR_EXISTS( 
YEAR_ID_IN integer(10),
YEAR_ID_v integer(10),
YEAR_ID integer(10)
);
