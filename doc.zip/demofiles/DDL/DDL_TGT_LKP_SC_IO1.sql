CREATE TABLE TGT_LKP_SC_IO1( 
Contract varchar(20)
);
