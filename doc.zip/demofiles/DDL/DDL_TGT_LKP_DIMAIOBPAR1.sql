CREATE TABLE TGT_LKP_DIMAIOBPAR1( 
Business_Partner varchar(20),
Profit_Ctr varchar(20),
Policy_Symbol varchar(20)
);
