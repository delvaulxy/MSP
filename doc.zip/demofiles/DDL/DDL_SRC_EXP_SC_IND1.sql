CREATE TABLE SRC_EXP_SC_IND1( 
IND_SC varchar(1),
RMW_Object_IO varchar(20),
RMW_Object_bPartner varchar(20)
);
