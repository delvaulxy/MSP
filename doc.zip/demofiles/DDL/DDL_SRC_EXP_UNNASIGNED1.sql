CREATE TABLE SRC_EXP_UNNASIGNED1( 
REP_BROKER varchar(11),
LOB varchar(10),
Country_BU_Code varchar(3),
SMU_Code varchar(10),
REP_BROKER_IN varchar(11),
LOB_IN varchar(3),
Country_BU_Code_IN varchar(3),
SMU_Code_IN varchar(10),
CoCd_IN varchar(5)
);
