CREATE TABLE SRC_LKP_LOB_POLICY_SYMBOL1( 
Symbol varchar(4),
LOB varchar(3),
Line varchar(255),
Description varchar(255),
Policy_Symbol_IN varchar(20)
);
