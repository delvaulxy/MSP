CREATE TABLE SRC_LKP_BROKER1( 
FIELD1 varchar(1),
INS_OBJECT varchar(22),
BUSINESS_PARTNER varchar(16),
REP_BROKER varchar(11),
BROKER_CON varchar(15),
DATE_FROM varchar(10),
TO_DATE varchar(10),
POLICY_IN varchar(21),
BPARTNER_IN varchar(11),
PostDate varchar(10)
);
