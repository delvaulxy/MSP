CREATE TABLE TGT_LKP_SC_PARTNER( 
Contract varchar(20)
);
