CREATE TABLE TGT_LKP_DIMAIOBPAR( 
Profit_Ctr varchar(20),
Policy_Symbol varchar(20)
);
