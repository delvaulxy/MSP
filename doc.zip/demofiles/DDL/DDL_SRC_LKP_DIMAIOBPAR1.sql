CREATE TABLE SRC_LKP_DIMAIOBPAR1( 
Ins_Object varchar(20),
Business_Partner varchar(20),
Profit_Ctr varchar(20),
Policy_Symbol varchar(20),
Producer_Code varchar(20),
Region varchar(20),
Business_Unit varchar(20),
Sub_Business_Unit varchar(20),
Office varchar(20),
Product_category varchar(20),
Bill_Tag varchar(20),
Policy_Number_without_Mod varchar(20),
Policy_mod varchar(20),
Effective_Date varchar(20),
Expiration_Date varchar(20),
Cesar_Policy_Number varchar(20),
POLICY_IN varchar(21)
);
