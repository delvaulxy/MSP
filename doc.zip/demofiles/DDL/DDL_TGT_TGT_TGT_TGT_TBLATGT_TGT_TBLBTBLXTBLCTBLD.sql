CREATE TABLE TGT_TGT_TGT_TGT_TBLATGT_TGT_TBLBTBLXTBLCTBLD( 
AA1 varchar(10),
AA2 varchar(10),
AA3 varchar(10),
AA4 varchar(10),
BB1 varchar(10),
CC5 varchar(10),
CC1 varchar(10)
);
