CREATE TABLE TGT_EXP_UNNASIGNED1( 
REP_BROKER varchar(11),
LOB varchar(10),
Country_BU_Code varchar(3),
SMU_Code varchar(10)
);
