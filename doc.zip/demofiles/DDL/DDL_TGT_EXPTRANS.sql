CREATE TABLE TGT_EXPTRANS( 
FIELD1 varchar(10),
FIELD2 varchar(10),
FIELD3 varchar(10),
FIELD4 varchar(10)
);
