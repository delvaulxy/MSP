CREATE TABLE SRC_EXP_COA_TRANS1( 
CASH_ON_ACCOUNT varchar(1),
Mtra varchar(4),
Stra varchar(4),
MTra1 varchar(5),
STra1 varchar(5)
);
