CREATE TABLE SRC_LKP_SC_IO1( 
Type varchar(8),
Process varchar(10),
Insured varchar(15),
Contract varchar(20),
ContractAccount varchar(16),
DocumentNumber varchar(100),
Owner varchar(100),
CollAgency varchar(10),
CollAgencyName varchar(10),
CollAgencyDate varchar(10),
CrDate datetime(29),
PrBDReserve varchar(10),
NonPrBDReserve varchar(10),
POLICY varchar(21),
SC_IO varchar(10),
Business_Partner varchar(20)
);
