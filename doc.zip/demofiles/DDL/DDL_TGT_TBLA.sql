CREATE TABLE TGT_TBLA( 
AA1 varchar(10),
AA2 varchar(10),
AA3 varchar(10),
AA4 varchar(10)
);
