CREATE TABLE TGT_EXP_UNGROUP_PREV( 
BASE_YEAR_ACCUM_ID integer(10),
YEAR_ACCUM_ID small integer(5),
YEAR_ID integer(10),
BASE_YEAR_ACCUM_ID2 integer(10),
YEAR_ACCUM_ID2 small integer(5),
YEAR_ID2 integer(10),
BASE_YEAR_ACCUM_ID integer(10),
YEAR_ACCUM_ID small integer(5),
YEAR_ID integer(10),
BASE_YEAR_ACCUM_ID3 integer(10),
YEAR_ACCUM_ID3 small integer(5),
YEAR_ID3 integer(10)
);
