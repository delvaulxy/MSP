CREATE TABLE SRC_LKP_SC_PARTNER( 
Type varchar(8),
Process varchar(10),
Insured varchar(15),
Contract varchar(20),
ContractAccount varchar(16),
DocumentNumber varchar(100),
Owner varchar(100),
CollAgency varchar(10),
CollAgencyName varchar(10),
CollAgencyDate varchar(10),
CrDate datetime(29),
PrBDReserve varchar(10),
NonPrBDReserve varchar(10),
BPARTNER varchar(11),
SC_Partner varchar(10)
);
