CREATE TABLE TGT_LKP_SC_PARTNER1( 
Contract varchar(20)
);
