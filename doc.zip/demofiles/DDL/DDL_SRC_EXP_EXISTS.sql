CREATE TABLE SRC_EXP_EXISTS( 
MONTH_ID_IN integer(10),
MONTH_ID_v integer(10),
MONTH_ID integer(10)
);
