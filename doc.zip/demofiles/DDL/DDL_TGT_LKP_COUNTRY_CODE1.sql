CREATE TABLE TGT_LKP_COUNTRY_CODE1( 
Company_Codes varchar(3),
Descriptions varchar(25),
City varchar(10),
Country varchar(2),
Country_new varchar(3),
Currency varchar(3),
CoCd varchar(5)
);
