CREATE TABLE TGT_LKP_COA_MAIN_SUB( 
Mtra varchar(4),
Stra varchar(4),
MTra1 varchar(5),
STra1 varchar(5)
);
