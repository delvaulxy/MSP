CREATE TABLE TGT_LKP_HEIRARCHY( 
Country_BU_Code varchar(3),
SMU_Code varchar(10)
);
