CREATE TABLE TGT_LKP_SC_IO( 
Contract varchar(20)
);
