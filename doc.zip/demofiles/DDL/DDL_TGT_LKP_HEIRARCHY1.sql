CREATE TABLE TGT_LKP_HEIRARCHY1( 
Country_BU_Code varchar(3),
SMU_Code varchar(10)
);
