//
// Este archivo ha sido generado por la arquitectura JavaTM para la implantaci�n de la referencia de enlace (JAXB) XML v2.2.11 
// Visite <a href="http://java.sun.com/xml/jaxb">http://java.sun.com/xml/jaxb</a> 
// Todas las modificaciones realizadas en este archivo se perder�n si se vuelve a compilar el esquema de origen. 
// Generado el: 2016.02.12 a las 12:05:52 PM CET 
//


package corp.everis.pwc.raw;

import javax.xml.bind.annotation.XmlRegistry;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the corp.everis.pwc.raw package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {


    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: corp.everis.pwc.raw
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link TARGET }
     * 
     */
    public TARGET createTARGET() {
        return new TARGET();
    }

    /**
     * Create an instance of {@link KEYWORD }
     * 
     */
    public KEYWORD createKEYWORD() {
        return new KEYWORD();
    }

    /**
     * Create an instance of {@link FLATFILE }
     * 
     */
    public FLATFILE createFLATFILE() {
        return new FLATFILE();
    }

    /**
     * Create an instance of {@link XMLINFO }
     * 
     */
    public XMLINFO createXMLINFO() {
        return new XMLINFO();
    }

    /**
     * Create an instance of {@link GROUP }
     * 
     */
    public GROUP createGROUP() {
        return new GROUP();
    }

    /**
     * Create an instance of {@link TARGETFIELD }
     * 
     */
    public TARGETFIELD createTARGETFIELD() {
        return new TARGETFIELD();
    }

    /**
     * Create an instance of {@link TARGETINDEX }
     * 
     */
    public TARGETINDEX createTARGETINDEX() {
        return new TARGETINDEX();
    }

    /**
     * Create an instance of {@link TABLEATTRIBUTE }
     * 
     */
    public TABLEATTRIBUTE createTABLEATTRIBUTE() {
        return new TABLEATTRIBUTE();
    }

    /**
     * Create an instance of {@link METADATAEXTENSION }
     * 
     */
    public METADATAEXTENSION createMETADATAEXTENSION() {
        return new METADATAEXTENSION();
    }

    /**
     * Create an instance of {@link CONNECTIONREFERENCE }
     * 
     */
    public CONNECTIONREFERENCE createCONNECTIONREFERENCE() {
        return new CONNECTIONREFERENCE();
    }

    /**
     * Create an instance of {@link ATTRIBUTE }
     * 
     */
    public ATTRIBUTE createATTRIBUTE() {
        return new ATTRIBUTE();
    }

    /**
     * Create an instance of {@link MACROARGUMENT }
     * 
     */
    public MACROARGUMENT createMACROARGUMENT() {
        return new MACROARGUMENT();
    }

    /**
     * Create an instance of {@link SEBLSRCINFO }
     * 
     */
    public SEBLSRCINFO createSEBLSRCINFO() {
        return new SEBLSRCINFO();
    }

    /**
     * Create an instance of {@link SEBLJOIN }
     * 
     */
    public SEBLJOIN createSEBLJOIN() {
        return new SEBLJOIN();
    }

    /**
     * Create an instance of {@link SEBLLINK }
     * 
     */
    public SEBLLINK createSEBLLINK() {
        return new SEBLLINK();
    }

    /**
     * Create an instance of {@link SEBLMVLINK }
     * 
     */
    public SEBLMVLINK createSEBLMVLINK() {
        return new SEBLMVLINK();
    }

    /**
     * Create an instance of {@link SEBLMVLINKREL }
     * 
     */
    public SEBLMVLINKREL createSEBLMVLINKREL() {
        return new SEBLMVLINKREL();
    }

    /**
     * Create an instance of {@link TARGETLOADORDER }
     * 
     */
    public TARGETLOADORDER createTARGETLOADORDER() {
        return new TARGETLOADORDER();
    }

    /**
     * Create an instance of {@link SESSTRANSFORMATIONINST }
     * 
     */
    public SESSTRANSFORMATIONINST createSESSTRANSFORMATIONINST() {
        return new SESSTRANSFORMATIONINST();
    }

    /**
     * Create an instance of {@link SESSTRANSFORMATIONGROUP }
     * 
     */
    public SESSTRANSFORMATIONGROUP createSESSTRANSFORMATIONGROUP() {
        return new SESSTRANSFORMATIONGROUP();
    }

    /**
     * Create an instance of {@link PARTITION }
     * 
     */
    public PARTITION createPARTITION() {
        return new PARTITION();
    }

    /**
     * Create an instance of {@link HASHKEY }
     * 
     */
    public HASHKEY createHASHKEY() {
        return new HASHKEY();
    }

    /**
     * Create an instance of {@link SAPSTRUCTURE }
     * 
     */
    public SAPSTRUCTURE createSAPSTRUCTURE() {
        return new SAPSTRUCTURE();
    }

    /**
     * Create an instance of {@link SAPSTRUCTUREFIELD }
     * 
     */
    public SAPSTRUCTUREFIELD createSAPSTRUCTUREFIELD() {
        return new SAPSTRUCTUREFIELD();
    }

    /**
     * Create an instance of {@link TARGETINDEXFIELD }
     * 
     */
    public TARGETINDEXFIELD createTARGETINDEXFIELD() {
        return new TARGETINDEXFIELD();
    }

    /**
     * Create an instance of {@link SAPPROGRAM }
     * 
     */
    public SAPPROGRAM createSAPPROGRAM() {
        return new SAPPROGRAM();
    }

    /**
     * Create an instance of {@link RESOURCEREFERENCE }
     * 
     */
    public RESOURCEREFERENCE createRESOURCEREFERENCE() {
        return new RESOURCEREFERENCE();
    }

    /**
     * Create an instance of {@link CONFIG }
     * 
     */
    public CONFIG createCONFIG() {
        return new CONFIG();
    }

    /**
     * Create an instance of {@link WORKFLOWLINK }
     * 
     */
    public WORKFLOWLINK createWORKFLOWLINK() {
        return new WORKFLOWLINK();
    }

    /**
     * Create an instance of {@link EXPRMACRODEPENDENCY }
     * 
     */
    public EXPRMACRODEPENDENCY createEXPRMACRODEPENDENCY() {
        return new EXPRMACRODEPENDENCY();
    }

    /**
     * Create an instance of {@link SAPFUNCTIONINSTANCE }
     * 
     */
    public SAPFUNCTIONINSTANCE createSAPFUNCTIONINSTANCE() {
        return new SAPFUNCTIONINSTANCE();
    }

    /**
     * Create an instance of {@link SAPFUNCINSTANCEPARAM }
     * 
     */
    public SAPFUNCINSTANCEPARAM createSAPFUNCINSTANCEPARAM() {
        return new SAPFUNCINSTANCEPARAM();
    }

    /**
     * Create an instance of {@link SAPTABLEINSTANCEPARAM }
     * 
     */
    public SAPTABLEINSTANCEPARAM createSAPTABLEINSTANCEPARAM() {
        return new SAPTABLEINSTANCEPARAM();
    }

    /**
     * Create an instance of {@link STARTOPTIONS }
     * 
     */
    public STARTOPTIONS createSTARTOPTIONS() {
        return new STARTOPTIONS();
    }

    /**
     * Create an instance of {@link SCHEDULER }
     * 
     */
    public SCHEDULER createSCHEDULER() {
        return new SCHEDULER();
    }

    /**
     * Create an instance of {@link SCHEDULEINFO }
     * 
     */
    public SCHEDULEINFO createSCHEDULEINFO() {
        return new SCHEDULEINFO();
    }

    /**
     * Create an instance of {@link FIELDATTRIBUTE }
     * 
     */
    public FIELDATTRIBUTE createFIELDATTRIBUTE() {
        return new FIELDATTRIBUTE();
    }

    /**
     * Create an instance of {@link MAPPING }
     * 
     */
    public MAPPING createMAPPING() {
        return new MAPPING();
    }

    /**
     * Create an instance of {@link TRANSFORMATION }
     * 
     */
    public TRANSFORMATION createTRANSFORMATION() {
        return new TRANSFORMATION();
    }

    /**
     * Create an instance of {@link INSTANCE }
     * 
     */
    public INSTANCE createINSTANCE() {
        return new INSTANCE();
    }

    /**
     * Create an instance of {@link CONNECTOR }
     * 
     */
    public CONNECTOR createCONNECTOR() {
        return new CONNECTOR();
    }

    /**
     * Create an instance of {@link MAPDEPENDENCY }
     * 
     */
    public MAPDEPENDENCY createMAPDEPENDENCY() {
        return new MAPDEPENDENCY();
    }

    /**
     * Create an instance of {@link MAPPINGVARIABLE }
     * 
     */
    public MAPPINGVARIABLE createMAPPINGVARIABLE() {
        return new MAPPINGVARIABLE();
    }

    /**
     * Create an instance of {@link ERPINFO }
     * 
     */
    public ERPINFO createERPINFO() {
        return new ERPINFO();
    }

    /**
     * Create an instance of {@link SAPFUNCINSTANCEPARAMFLD }
     * 
     */
    public SAPFUNCINSTANCEPARAMFLD createSAPFUNCINSTANCEPARAMFLD() {
        return new SAPFUNCINSTANCEPARAMFLD();
    }

    /**
     * Create an instance of {@link ASSOCIATEDSOURCEINSTANCE }
     * 
     */
    public ASSOCIATEDSOURCEINSTANCE createASSOCIATEDSOURCEINSTANCE() {
        return new ASSOCIATEDSOURCEINSTANCE();
    }

    /**
     * Create an instance of {@link KEYRANGE }
     * 
     */
    public KEYRANGE createKEYRANGE() {
        return new KEYRANGE();
    }

    /**
     * Create an instance of {@link MACRODEPENDENCY }
     * 
     */
    public MACRODEPENDENCY createMACRODEPENDENCY() {
        return new MACRODEPENDENCY();
    }

    /**
     * Create an instance of {@link FOLDER }
     * 
     */
    public FOLDER createFOLDER() {
        return new FOLDER();
    }

    /**
     * Create an instance of {@link FOLDERVERSION }
     * 
     */
    public FOLDERVERSION createFOLDERVERSION() {
        return new FOLDERVERSION();
    }

    /**
     * Create an instance of {@link TASK }
     * 
     */
    public TASK createTASK() {
        return new TASK();
    }

    /**
     * Create an instance of {@link SESSION }
     * 
     */
    public SESSION createSESSION() {
        return new SESSION();
    }

    /**
     * Create an instance of {@link WORKLET }
     * 
     */
    public WORKLET createWORKLET() {
        return new WORKLET();
    }

    /**
     * Create an instance of {@link WORKFLOW }
     * 
     */
    public WORKFLOW createWORKFLOW() {
        return new WORKFLOW();
    }

    /**
     * Create an instance of {@link SOURCE }
     * 
     */
    public SOURCE createSOURCE() {
        return new SOURCE();
    }

    /**
     * Create an instance of {@link MAPPLET }
     * 
     */
    public MAPPLET createMAPPLET() {
        return new MAPPLET();
    }

    /**
     * Create an instance of {@link SHORTCUT }
     * 
     */
    public SHORTCUT createSHORTCUT() {
        return new SHORTCUT();
    }

    /**
     * Create an instance of {@link EXPRMACRO }
     * 
     */
    public EXPRMACRO createEXPRMACRO() {
        return new EXPRMACRO();
    }

    /**
     * Create an instance of {@link TIMER }
     * 
     */
    public TIMER createTIMER() {
        return new TIMER();
    }

    /**
     * Create an instance of {@link VALUEPAIR }
     * 
     */
    public VALUEPAIR createVALUEPAIR() {
        return new VALUEPAIR();
    }

    /**
     * Create an instance of {@link TRANSFORMFIELDATTRDEF }
     * 
     */
    public TRANSFORMFIELDATTRDEF createTRANSFORMFIELDATTRDEF() {
        return new TRANSFORMFIELDATTRDEF();
    }

    /**
     * Create an instance of {@link ENDOPTIONS }
     * 
     */
    public ENDOPTIONS createENDOPTIONS() {
        return new ENDOPTIONS();
    }

    /**
     * Create an instance of {@link TRANSFORMFIELD }
     * 
     */
    public TRANSFORMFIELD createTRANSFORMFIELD() {
        return new TRANSFORMFIELD();
    }

    /**
     * Create an instance of {@link TRANSFORMFIELDATTR }
     * 
     */
    public TRANSFORMFIELDATTR createTRANSFORMFIELDATTR() {
        return new TRANSFORMFIELDATTR();
    }

    /**
     * Create an instance of {@link SAPPROGRAMFLOWOBJECT }
     * 
     */
    public SAPPROGRAMFLOWOBJECT createSAPPROGRAMFLOWOBJECT() {
        return new SAPPROGRAMFLOWOBJECT();
    }

    /**
     * Create an instance of {@link SAPCODEBLOCK }
     * 
     */
    public SAPCODEBLOCK createSAPCODEBLOCK() {
        return new SAPCODEBLOCK();
    }

    /**
     * Create an instance of {@link SCHEDULEOPTIONS }
     * 
     */
    public SCHEDULEOPTIONS createSCHEDULEOPTIONS() {
        return new SCHEDULEOPTIONS();
    }

    /**
     * Create an instance of {@link INITPROP }
     * 
     */
    public INITPROP createINITPROP() {
        return new INITPROP();
    }

    /**
     * Create an instance of {@link RECURRING }
     * 
     */
    public RECURRING createRECURRING() {
        return new RECURRING();
    }

    /**
     * Create an instance of {@link SESSIONCOMPONENT }
     * 
     */
    public SESSIONCOMPONENT createSESSIONCOMPONENT() {
        return new SESSIONCOMPONENT();
    }

    /**
     * Create an instance of {@link ERPSRCINFO }
     * 
     */
    public ERPSRCINFO createERPSRCINFO() {
        return new ERPSRCINFO();
    }

    /**
     * Create an instance of {@link CONWFRUNINFO }
     * 
     */
    public CONWFRUNINFO createCONWFRUNINFO() {
        return new CONWFRUNINFO();
    }

    /**
     * Create an instance of {@link POWERMART }
     * 
     */
    public POWERMART createPOWERMART() {
        return new POWERMART();
    }

    /**
     * Create an instance of {@link REPOSITORY }
     * 
     */
    public REPOSITORY createREPOSITORY() {
        return new REPOSITORY();
    }

    /**
     * Create an instance of {@link SOURCEFIELD }
     * 
     */
    public SOURCEFIELD createSOURCEFIELD() {
        return new SOURCEFIELD();
    }

    /**
     * Create an instance of {@link SAPFUNCTION }
     * 
     */
    public SAPFUNCTION createSAPFUNCTION() {
        return new SAPFUNCTION();
    }

    /**
     * Create an instance of {@link SAPFUNCPARAM }
     * 
     */
    public SAPFUNCPARAM createSAPFUNCPARAM() {
        return new SAPFUNCPARAM();
    }

    /**
     * Create an instance of {@link SAPTABLEPARAM }
     * 
     */
    public SAPTABLEPARAM createSAPTABLEPARAM() {
        return new SAPTABLEPARAM();
    }

    /**
     * Create an instance of {@link WORKFLOWEVENT }
     * 
     */
    public WORKFLOWEVENT createWORKFLOWEVENT() {
        return new WORKFLOWEVENT();
    }

    /**
     * Create an instance of {@link REPEAT }
     * 
     */
    public REPEAT createREPEAT() {
        return new REPEAT();
    }

    /**
     * Create an instance of {@link FILTER }
     * 
     */
    public FILTER createFILTER() {
        return new FILTER();
    }

    /**
     * Create an instance of {@link FIELDDEPENDENCY }
     * 
     */
    public FIELDDEPENDENCY createFIELDDEPENDENCY() {
        return new FIELDDEPENDENCY();
    }

    /**
     * Create an instance of {@link DAILYFREQUENCY }
     * 
     */
    public DAILYFREQUENCY createDAILYFREQUENCY() {
        return new DAILYFREQUENCY();
    }

    /**
     * Create an instance of {@link CONFIGREFERENCE }
     * 
     */
    public CONFIGREFERENCE createCONFIGREFERENCE() {
        return new CONFIGREFERENCE();
    }

    /**
     * Create an instance of {@link SAPOUTPUTPORT }
     * 
     */
    public SAPOUTPUTPORT createSAPOUTPUTPORT() {
        return new SAPOUTPUTPORT();
    }

    /**
     * Create an instance of {@link CUSTOM }
     * 
     */
    public CUSTOM createCUSTOM() {
        return new CUSTOM();
    }

    /**
     * Create an instance of {@link TRANSFORMRESOURCEREF }
     * 
     */
    public TRANSFORMRESOURCEREF createTRANSFORMRESOURCEREF() {
        return new TRANSFORMRESOURCEREF();
    }

    /**
     * Create an instance of {@link SAPVARIABLE }
     * 
     */
    public SAPVARIABLE createSAPVARIABLE() {
        return new SAPVARIABLE();
    }

    /**
     * Create an instance of {@link SESSIONEXTENSION }
     * 
     */
    public SESSIONEXTENSION createSESSIONEXTENSION() {
        return new SESSIONEXTENSION();
    }

    /**
     * Create an instance of {@link TASKINSTANCE }
     * 
     */
    public TASKINSTANCE createTASKINSTANCE() {
        return new TASKINSTANCE();
    }

    /**
     * Create an instance of {@link WORKFLOWVARIABLE }
     * 
     */
    public WORKFLOWVARIABLE createWORKFLOWVARIABLE() {
        return new WORKFLOWVARIABLE();
    }

    /**
     * Create an instance of {@link XMLTEXT }
     * 
     */
    public XMLTEXT createXMLTEXT() {
        return new XMLTEXT();
    }

}
