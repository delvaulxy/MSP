package corp.everis.pwc.moam;

import java.util.ArrayList;

import corp.everis.pwc.moam.ISentence;
import corp.everis.pwc.moam.ShuntingYard;
import corp.everis.pwc.raw.CONNECTOR;
import corp.everis.pwc.raw.SOURCE;
import corp.everis.pwc.raw.SOURCEFIELD;
import corp.everis.pwc.raw.TABLEATTRIBUTE;
import corp.everis.pwc.raw.TARGET;
import corp.everis.pwc.raw.TARGETFIELD;
import corp.everis.pwc.raw.TRANSFORMATION;
import corp.everis.pwc.raw.TRANSFORMFIELD;

public class Joiner extends TRANSFORMATION implements ISentence{
	protected ArrayList<SOURCE> sources;
	protected ArrayList<TARGET> targets;
	protected ArrayList<CONNECTOR> connectors;
	protected static ShuntingYard sy = new ShuntingYard();

	protected String sentence;

	public Joiner() {
		super();
		this.sources = new ArrayList<SOURCE>();
		this.targets = new ArrayList<TARGET>();
		this.sentence = new String();
	}

	public Joiner(ArrayList<SOURCE> srcs, ArrayList<TARGET> tgts) {
		super();
		this.sources = new ArrayList<SOURCE>();
		this.targets = new ArrayList<TARGET>();
		this.sentence = new String();
	}

	public ArrayList<SOURCE> getSources() {
		return sources;
	}

	public void setSources(ArrayList<SOURCE> sources) {
		this.sources = sources;
	}

	public void addSource(SOURCE source){
		this.sources.add(source);
	}

	public ArrayList<TARGET> getTargets() {
		return targets;
	}

	public void setTargets(ArrayList<TARGET> targets) {
		this.targets = targets;
	}

	public void addTarget(TARGET target){
		this.targets.add(target);
	}

	public String getSentence() {
		return this.sentence;
	}

	public void setSentence(String sentence) {
		this.sentence = sentence;
	}

	public ArrayList<CONNECTOR> getConnnectors() {
		return connectors;
	}

	public void setConnnectors(ArrayList<CONNECTOR> connectors) {
		this.connectors = connectors;
	}

	public void addConnector(CONNECTOR connector){
		this.connectors.add(connector);
	}


	@Override
	public void toSentence() {
		String master = "";
		String detail = "";
		String condition = "";

		if(XMLParser.getLanguage().equals("SQL")){

			for(TARGET t : targets){
				this.sentence = "INSERT INTO "+ "\n " + t.getNAME()+ "\n ";
				for(TARGETFIELD tf : t.getTARGETFIELD())
					this.sentence = this.sentence + " ("+tf.getNAME()+"),";
			}
			this.sentence = this.sentence.substring(0, this.sentence.length()-1)+ "\n ";
			this.sentence = this.sentence + " SELECT "+ "\n ";

			// SELECT mastertable.field1, mastertable.field2, detailtable.field1,detailtable.field2 
			for(SOURCE s : this.getSources()){
				for(SOURCEFIELD sf : s.getSOURCEFIELD())

					if(s.getNAME().contains("MASTER")){
						this.sentence = this.sentence + "M."+sf.getNAME()+", ";
						master = s.getNAME();
					}else{
						this.sentence = this.sentence +"D."+sf.getNAME()+", ";
						detail = s.getNAME();
					}
			}

			// from master 
			this.sentence = this.sentence.substring(0, this.sentence.length()-1)+ "\n ";
			this.sentence = this.sentence + " FROM "+ "\n "+ master + " M ";

			// JOINTYPE
			for(TABLEATTRIBUTE ta : this.getTABLEATTRIBUTE())
				if(ta.getNAME().equals("Join Type")){
					switch(ta.getVALUE()){
					case "Normal Join":
						// normal join --> inner join detail on
						this.sentence = this.sentence + " INNER JOIN " + "\n"+detail +" D \n" +"ON" +"\n" ;	
						break;
					case "Full Outer Join":
						// Full outer join --> outer join on 
						this.sentence = this.sentence + " FULL OUTER JOIN " + "\n"+detail +" D \n" +"ON" +"\n" ;
						break;
					case "Master Join":
						// Master Join --> right outer join on 
						this.sentence = this.sentence + " RIGHT OUTER JOIN " + "\n"+detail +" D \n" +"ON" +"\n" ;
						break;
					case "Detail Join":
						// Detail Join --> left outer join on
						this.sentence = this.sentence + " LEFT OUTER JOIN " + "\n"+detail +" D \n" +"ON" +"\n" ;
						break;

					}
				}
			// condition
			for(TABLEATTRIBUTE ta : this.getTABLEATTRIBUTE())
				if(ta.getNAME().equals("Join Condition"))
					condition = ta.getVALUE();
			for(TRANSFORMFIELD tf : this.getTRANSFORMFIELD()){
				if(tf.getPORTTYPE().contains("MASTER"))
					condition = condition.replace(tf.getNAME(), "M."+tf.getNAME());
				else
					condition = condition.replace(tf.getNAME(), "D."+tf.getNAME());
			}
			this.sentence = this.sentence + sy.main(condition)+ "\n ";

			System.out.println(this.sentence);
		}else if(XMLParser.getLanguage().equals("Espa�ol")){
			String conditionSpanish = "";
			this.sentence = "CRISTINA: Dados los or�genes " + master + " (Master) y " + detail + " (Detail), se cruzar�n seg�n la condici�n: " + "\n "; 
			for(TABLEATTRIBUTE ta : this.getTABLEATTRIBUTE())
				if(ta.getNAME().equals("Join Condition"))
					conditionSpanish = ta.getVALUE();
			for(TRANSFORMFIELD tf : this.getTRANSFORMFIELD()){
				if(tf.getPORTTYPE().contains("MASTER"))
					conditionSpanish = conditionSpanish.replace(tf.getNAME(), "M."+tf.getNAME());
				else
					conditionSpanish = conditionSpanish.replace(tf.getNAME(), "D."+tf.getNAME());
			}
			this.sentence = this.sentence + conditionSpanish + "\n";
			this.sentence = this.sentence + "La salida tendr�: ";
			for(TABLEATTRIBUTE ta : this.getTABLEATTRIBUTE())
				if(ta.getNAME().equals("Join Type")){
					switch(ta.getVALUE()){
					case "Normal Join":
						// normal join --> inner join detail on
						this.sentence = this.sentence + "Todos los registros que coincidan de " + master + " y " + detail +".\n" ;     
						break;
					case "Full Outer Join":
						// Full outer join --> outer join on 
						this.sentence = this.sentence + "Todos los registros de " + master + " y " + detail +".\n" ;
						break;
					case "Master Join":
						// Master Join --> right outer join on 
						this.sentence = this.sentence + "Todos los registros de " + master + " y los que coincidan de " + detail +"\n" ;
						break;
					case "Detail Join":
						// Detail Join --> left outer join on
						this.sentence = this.sentence + "Todos los registros de " + detail + " y los que coincidan de " + master +"\n" ;
						break;

					}
				}

		}
	}

}
