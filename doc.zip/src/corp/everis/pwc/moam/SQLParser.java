package corp.everis.pwc.moam;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Stack;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import corp.everis.pwc.raw.ASSOCIATEDSOURCEINSTANCE;
import corp.everis.pwc.raw.ATTRIBUTE;
import corp.everis.pwc.raw.CONFIG;
import corp.everis.pwc.raw.CONFIGREFERENCE;
import corp.everis.pwc.raw.CONNECTOR;
import corp.everis.pwc.raw.FOLDER;
import corp.everis.pwc.raw.INSTANCE;
import corp.everis.pwc.raw.MAPPING;
import corp.everis.pwc.raw.POWERMART;
import corp.everis.pwc.raw.REPOSITORY;
import corp.everis.pwc.raw.SCHEDULER;
import corp.everis.pwc.raw.SESSION;
import corp.everis.pwc.raw.SOURCE;
import corp.everis.pwc.raw.SOURCEFIELD;
import corp.everis.pwc.raw.TABLEATTRIBUTE;
import corp.everis.pwc.raw.TARGET;
import corp.everis.pwc.raw.TARGETFIELD;
import corp.everis.pwc.raw.TARGETLOADORDER;
import corp.everis.pwc.raw.TASK;
import corp.everis.pwc.raw.TASKINSTANCE;
import corp.everis.pwc.raw.TRANSFORMATION;
import corp.everis.pwc.raw.TRANSFORMFIELD;
import corp.everis.pwc.raw.WORKFLOW;
import corp.everis.pwc.raw.WORKFLOWLINK;
import corp.everis.pwc.raw.WORKFLOWVARIABLE;

public class SQLParser {

	static String qry = "SELECT A.A1,A.A2,A.A3,A.A4,C.C5 FROM TBLA A LEFT OUTER JOIN (SELECT B.B1 FROM TBLB) AS B ON A.A1 = B.B1 LEFT OUTER JOIN TBLC C ON B.B1 = C.C1 LEFT OUTER JOIN TBLD D ON B.B1 = D.D1";
	//static String qry = "SELECT A.A1,A.A2,C.C1 FROM TBLA A LEFT OUTER JOIN TBLB B ON A.A1 = B.B1 LEFT OUTER JOIN TBLC C ON B.B1 = C.C1";
	static ArrayList<String> sfOther = new ArrayList<String>();
	static ArrayList<String> sOldTables = new ArrayList<String>();
	//static String qry = "SELECT DISTINCT A1, A2,A3,A4,A5 FROM A LEFT JOIN (SELECT * FROM CC) C ON B.1 = C.1 LEFT JOIN D ON B.1 = D.1 LEFT JOIN E ON B.1 = E.1 LEFT JOIN F ON B.1 = F.1 LEFT JOIN G ON B.1 = G.1;";
	//static String qry = "SELECT A.CAMPOA, A.CAMPOB,A.CAMPOC,B.CAMPOA,B.CAMPOB, B.CAMPOC FROM TABLEA A LEFT OUTER JOIN TABLEB B ON A.CAMPOC = B.CAMPOC AND A.CAMPOC > 1;";
	//static String qry = "SELECT SUM(A +B) FROM (SELECT A,B,(SELECT C.C FROM X INNER JOIN L ON C.C = L.M) AS C FROM Y INNER JOIN (SELECT D FROM Z) AS XYZ)";
	//static String qry = "SELECT NOMIX.CIFNIF AS NIF_CLIENTE,NOMIX.NUM_CLIENTE,NOMIX.COD_ESTADO_GENERAL,NOMIX.TIPO_DOCUMENTO_NORM,NOMIX.CLASE_CLI_COD_CLASE_CLIENTE,NOMIX.DES_TIPO_CLIENTE,NOMIX.DES_SUBTIPO_CLIENTE,NOMIX.CIF_CABECERA,SEGM_ACT.COD_SEGMENTO AS COD_SEGM_ANT, SEGM_ACT.FEC_SEGMENTO,NOMIX.GRUPO_COMERCIAL,NOMIX.ANTIG_MESES,NOMIX.FEC_INSTALACION,CURRENT_TIMESTAMP AS FECHA_CARGA	FROM ${DBDWHV}.${V_MS_CLIENTES_NO_MIXTOS} NOMIX	LEFT OUTER JOIN (SELECT ${DBDWHV}.${V_HC_MS_HIST_SEGMENTO_MERCADO}.NIF_CLIENTE, ${DBDWHV}.${V_HC_MS_HIST_SEGMENTO_MERCADO}.COD_SEGMENTO, ${DBDWHV}.${V_HC_MS_HIST_SEGMENTO_MERCADO}.FEC_SEGMENTO FROM ${DBDWHV}.${V_HC_MS_HIST_SEGMENTO_MERCADO}) SEGM_ACT ON NOMIX.CIFNIF =SEGM_ACT.NIF_CLIENTE WHERE CAST(NOMIX.FEC_INSTALACION AS DATE FORMAT 'YYYYMMDD') > CAST('${FEC_ANT}' AS DATE FORMAT 'YYYYMMDD') 	AND  CAST(NOMIX.FEC_INSTALACION AS DATE FORMAT 'YYYYMMDD') <= CAST('${FEC_ACT}' AS DATE FORMAT 'YYYYMMDD')";


	// check for keywords indicating a specific transformation.

	final static String kw = new String(""
			+ "(?<=FROM)|(?=FROM)|"
			+ "(?<!LEFT\\sOUTER|RIGHT\\sOUTER)(?=\\sJOIN\\s)|"
			+ "(?<!LEFT\\sOUTER|RIGHT\\sOUTER)(?<=\\sJOIN\\s)|"
			+ "(?=LEFT\\sOUTER|RIGHT\\sOUTER)(?!\\sJOIN\\s)|"
			+ "(?<=LEFT\\sOUTER|RIGHT\\sOUTER)(?!\\sJOIN\\s)|"
			+ "(?<=LEFT\\sOUTER\\sJOIN\\s|RIGHT\\sOUTER\\sJOIN\\s)|"
			+ "(?=LEFT\\sOUTER\\sJOIN\\s|RIGHT\\sOUTER\\sJOIN\\s)|"
			+ "(?<=FULL\\sOUTER\\sJOIN\\s|INNER\\sJOIN\\s)|"
			+ "(?=FULL\\sOUTER\\sJOIN\\s|INNER\\sJOIN\\s)|"
			+ "(?<=\\sON\\s)|(?=\\sON\\s)|"
			+ "(?<=\\sAND\\s)|(?=\\sAND\\s)|"
			+ "(?<=\\sWHERE\\s)|(?=\\sWHERE\\s)|"
			+ "(?<=\\sAS\\s)|(?=\\sAS\\s)|"
			+ "(?<=\\sSELECT\\s)|(?=\\sSELECT\\s)|"
			+ "(?<=\\bSELECT\\s)|(?=\\bSELECT\\s)|"
			+ "(?<=\\sSUM\\s)|(?=\\sSUM\\s)|"
			+ "(?<=\\sSUM)|(?=\\sSUM)|"
			+ "(?<==)|(?==)|"
			+ "(?<=\\))|(?=\\))|"
			+ "(?<=\\()|(?=\\()");

	public String main(String s){
		qry = qry.toUpperCase();

		for(String part : qry.split(kw))
			System.out.println(part);

		return s;
	}

	public static void main(String[] args) {
		// WE DISSECT THE ORIGINAL QUERY
		System.out.println(dissectQRY(qry));
	}

	public static String dissectQRY(String query){
		String tmp = "";
		String tmpquery = query;
		String subquery = "";
		while(tmpquery.contains("(")){
			if(tmpquery.substring(tmpquery.indexOf("(")).trim().startsWith("SELECT")){
				subquery = tmpquery.substring(tmpquery.indexOf("(")+1);
				subquery = subquery.substring(0,subquery.indexOf(")")-1);
				subquery = dissectQRY(subquery);
			}else{
				tmpquery = tmpquery.substring(tmpquery.indexOf("("));
			}
		}
		while(tmpquery.contains(" JOIN ")){
			tmp = tmpquery.substring(0, tmpquery.indexOf(getJoinCondition(tmpquery).get(getJoinCondition(tmpquery).size()-1)));
			tmpquery = tmpquery.replace(tmp, dissectQRY(tmp));
		}
		// TURN QUERY INTO POWERMART
		processQRY(tmpquery);
		return "";
	}
	
	private static POWERMART processQRY(String query){
		POWERMART pm = new POWERMART();
		ArrayList<String> masterfnames = new ArrayList<String>();
		ArrayList<String> detailfnames = new ArrayList<String>();
		ArrayList<String> othernames = new ArrayList<String>();
		
		String tmp = "";
		SubQuery sq = new SubQuery();
		
		sq.setQuery(query);
		tmp = query.substring(query.indexOf(" FROM ")+6).trim();
		sq.setTablename(tmp.substring(0,tmp.indexOf(" ")).trim());
		tmp = tmp.substring(tmp.indexOf(" ")).trim();
		sq.setAlias(tmp.substring(0,tmp.indexOf(" ")).trim());
		
		if(query.contains(" JOIN ")){
			tmp = tmp.substring(tmp.indexOf(" JOIN ")+6).trim();
			sq.setDetailname(tmp.substring(0,tmp.indexOf(" ")));
			tmp = tmp.substring(tmp.indexOf(" ")).trim();
			sq.setDetailalias(tmp.substring(0,tmp.indexOf(" ")));
		}
		// GET ALL FIELDNAMES
		tmp = query.trim().substring(query.trim().indexOf(" "), query.trim().indexOf(" FROM "));
		for(String fn : query.split(" "))
			if(fn.startsWith(sq.alias+"."))
				masterfnames.add(fn);
			else if(fn.startsWith(sq.detailalias+"."))
				detailfnames.add(fn);
			else if(fn.contains("."))
				othernames.add(fn);
		
		// CHECK WHAT KIND OF MAPPING WE NEED TO CREATE
		if(query.contains(" JOIN ")){
			
		}
		return null;
	}
	
	private static POWERMART createJoiner(SubQuery query){
		
		
		
		
		
		
		
		
		return null;
	}
	
	
	
	// THIS FUNCTION RETURNS AN ARRAYLIST OF STRINGS WITH THE CONDITION OF
	// THAT JOIN-QUERY
	private static ArrayList<String> getJoinCondition(String s){
		// FUNCTION THAT RETURNS AN ARRAYLIST OF STRINGS
		// WITH THE JOINCONDITION.
		ArrayList<String> conds = new ArrayList<String>();
		String condition = "";
		// WE CHECK WHERE THE CONDITION STARTS (AFTER THE ON IN THE JOIN)
		int i = s.indexOf("ON");
		String tmp = s.substring(i+3);
		String keyw ="";
		while(!tmp.equals("")){
			if(!isKeyWord(" "+keyw+" ")&&tmp.contains(" ")){
				// IF THE KEYWORD ISN'T A KEYWORD AND THE CONDITION CONTAINS AN EMPTY SPACE 
				// WE ADD THE NEXT PART TO THE CONDITION, FROM THE START UNTIL
				// THE NEXT SPACE.
				condition = condition + tmp.substring(0, tmp.indexOf(" ")+1);
				// WE SET TMP = SUBSTRING STARTING AFTER THE NEXT SPACE.
				tmp = tmp.substring(tmp.indexOf(" ")+1);
				// IN CASE THERE'S STILL ANOTHER SPACE IN TMP
				// WE SET KEYW = THE SUBSTRING FROM THE START UNTIL THAT SPACE,
				// SO THAT WE CAN CHECK IT AGAIN.
				if(tmp.indexOf(" ")>0)
					keyw = tmp.substring(0,tmp.indexOf(" "));
			}else if(tmp.contains(" ") && !keyw.trim().equals("AND")&& !keyw.trim().equals("OR")){
				condition = condition + tmp.substring(0, tmp.indexOf(" ")+1);
				tmp = tmp.substring(tmp.indexOf(" ")+1);
				if(tmp.indexOf(" ")>0)
					keyw = tmp.substring(0,tmp.indexOf(" "));
			}else if(!tmp.contains(" ")){
				// IN CASE KEYW IS A KEYWORD AND DOESN'T CONTAIN AN EMPTY SPACE 
				// WE ADD IT TO THE CONDITION AND ADD THAT CONDITION TO THE ARRAYLIST
				condition = condition + tmp;
				tmp = "";
				conds.add(condition);
				// WE RESET THE CONDITIONSTRING AND KEYWORDS
				condition = "";
				keyw = "";
			}else {
				// IN CASE WE DON'T HAVE ANY SPACES LEFT, 
				// WE CAN ASSUME WE'RE AT THE LAST KEYWORD OF OUR CONDITION
				// AND FINISH IT UP.
				tmp = tmp.substring(keyw.length());
				conds.add(condition);
				condition = "";
				keyw = "";
			}
		}
		return conds;
	}

	// THIS FUNCTION CHECKS IF A STRING IS A KEYWORD OR NOT, COMPARING IT WITH THE LIST KW
	private static boolean isKeyWord(String s){
		Pattern p = Pattern.compile(kw);
		Matcher m = p.matcher(s);

		if(m.find())
			return true;
		else
			return false;
	}

}
