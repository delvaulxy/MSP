package corp.everis.pwc.moam;

public interface ISentence {
	abstract void toSentence();
}
