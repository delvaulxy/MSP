package corp.everis.pwc.moam;

import java.io.File;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import javax.xml.bind.JAXB;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;

import org.kohsuke.rngom.binary.GroupPattern;

import corp.everis.pwc.raw.ASSOCIATEDSOURCEINSTANCE;
import corp.everis.pwc.raw.CONNECTOR;
import corp.everis.pwc.raw.FOLDER;
import corp.everis.pwc.raw.GROUP;
import corp.everis.pwc.raw.INSTANCE;
import corp.everis.pwc.raw.MAPPING;
import corp.everis.pwc.raw.POWERMART;
import corp.everis.pwc.raw.REPOSITORY;
import corp.everis.pwc.raw.SOURCE;
import corp.everis.pwc.raw.SOURCEFIELD;
import corp.everis.pwc.raw.TABLEATTRIBUTE;
import corp.everis.pwc.raw.TARGET;
import corp.everis.pwc.raw.TARGETFIELD;
import corp.everis.pwc.raw.TARGETLOADORDER;
import corp.everis.pwc.raw.TRANSFORMATION;
import corp.everis.pwc.raw.TRANSFORMFIELD;

public class MappingParser {
	//	private static boolean bPrintExp = false;
	//	private static boolean bPrintFil = false;
	//	private static boolean bPrintJnr = false;
	//	private static boolean bPrintLkp = false;
	//	private static boolean bPrintSrt = false;
	//	private static boolean bPrintAgg = false;
	//	private static boolean bPrintDetails = false;
	private static boolean bPrintExp = true;
	private static boolean bPrintFil = true;
	private static boolean bPrintJnr = true;
	private static boolean bPrintLkp = true;
	private static boolean bPrintSrt = true;
	private static boolean bPrintAgg = true;
	private static boolean bPrintDetails = true;
	private static String sourceFile = "demofiles/m_CSS55_DATE_UPDATE.XML";
	private static String outputPath = "./demofiles/";
	private static ArrayList<TRANSFORMATION> alTrns;
	@SuppressWarnings("unused")
	private static boolean firstrun = true;
	private static boolean bformat = true;
	public static String language = "SQL";


	public static void main(String[] args){
		ArrayList<POWERMART> pwms = new ArrayList<POWERMART>();
		try {
			// FICHERO DE ENTRADA
			File fInputFile = new File(sourceFile);
			// LEEMOS EL FICHERO DE ENTRADA CON JAXB, buscando el node que corresponde a la clase POWERMART y poniendolo en un objeto.
			POWERMART pwM = (POWERMART) JAXB.unmarshal(fInputFile,  POWERMART.class);



			if (pwM instanceof POWERMART){
				// SI EL OBJECTO EXISTE, VAMOS A DISSECTARLO, MAPPING POR MAPPING.
				for(int i = 0; i<pwM.getREPOSITORY().get(0).getFOLDER().get(0).getMAPPING().size();i++){
					//pwNEW = dissectWF(pwM,i);
					POWERMART pwNEW = new POWERMART();
					pwNEW.setCREATIONDATE(pwM.getCREATIONDATE());
					pwNEW.setREPOSITORYVERSION(pwM.getREPOSITORYVERSION());
					dissectWF(pwM,i);
					pwms.add(pwNEW);
				}
			}else{
				// ALERT USER OF PARSING ERROR
				System.out.println("Error parsing the file.");
			}





		} catch (Exception e) {
			throw(e);
		}

	}




	private static void dissectWF (POWERMART pm, Integer i){
		List<TARGET> targets = new ArrayList<TARGET>();
		FOLDER f = pm.getREPOSITORY().get(0).getFOLDER().get(0);
		MAPPING mOriginal = f.getMAPPING().get(i);
		MAPPING copia = mOriginal;

		for(TARGET tgt : f.getTARGET()){
			targets.add(tgt);
		}
		for(TARGET tgt : targets){
			checkPrev(tgt, mOriginal,f);
		}

	}

	private static void checkPrev(TARGET tgt, MAPPING mOriginal,FOLDER f){
		
		List<TRANSFORMATION> transformations = findPredecessor(tgt.getNAME(),mOriginal);
		TARGET target = new TARGET();
		Iterator itPreList = transformations.iterator();

		while(itPreList.hasNext()){

			TRANSFORMATION pre = (TRANSFORMATION) itPreList.next();	
			if("Union Transformation".equals(pre.getTEMPLATENAME())){
				int oGroupSize = pre.getGROUP().size()-1;

				for(int i=1;i<=oGroupSize;i++){
					GROUP group = pre.getGROUP().get(i);
					TARGET groupTGT = new TARGET(tgt);
					groupTGT.setNAME("TGT_"+pre.getNAME()+ Integer.toString(i));
					List<TRANSFORMATION> gPredecessor = new ArrayList<TRANSFORMATION>();
					for(TRANSFORMFIELD transformfield : pre.getTRANSFORMFIELD()){
						TRANSFORMATION t = findGroupPredecessor (pre.getNAME(),mOriginal,transformfield.getNAME());
						if(transformfield.getGROUP().equals(group.getNAME()) && !gPredecessor.contains(t)){
							gPredecessor.add(t);
						}
					}
					genGPartialMapping(pre,mOriginal,tgt,f,groupTGT,gPredecessor,group);
					
//					
//					SOURCE source = createSource(pre);
//					
//					target = sourceToTarget(source);
//					target.setNAME("TGT_"+pre.getNAME());
//					
//					if(!f.getTARGET().contains(target))
//						f.getTARGET().add(target);
//				
//					for(TRANSFORMATION trns : gPredecessor){
//						mOriginal = connectTargetToTrans (target,trns, mOriginal);
//					}
				}
			}else{
				SOURCE source = createSource(pre);
				
				target = sourceToTarget(source);
				target.setNAME("TGT_"+pre.getNAME());
				
				f.getTARGET().add(target);
				
				List<TRANSFORMATION> preTransformations = findPredecessor(pre.getNAME(),mOriginal);
				Iterator itPrePreList = preTransformations.iterator();
	
				while(itPrePreList.hasNext()){
					TRANSFORMATION prePre = (TRANSFORMATION) itPrePreList.next();
					mOriginal = connectTargetToTrans (target,prePre, mOriginal);
				}
				//writeToXML(createMapping(tgt, pre, source,mOriginal));

				genPartialMapping(pre,mOriginal,tgt,f,target);
			}
		}

		if(!tgt.getNAME().contains("SQ_")){
			System.out.println(tgt.getNAME());
			checkPrev(target, mOriginal, f);	
		}
	}

	private static void genPartialMapping (TRANSFORMATION pre,MAPPING mOriginal,TARGET tgt,FOLDER f,TARGET target){
		SOURCE source = createSource(pre);

		target = sourceToTarget(source);
		target.setNAME("TGT_"+pre.getNAME());

		f.getTARGET().add(target);

		List<TRANSFORMATION> preTransformations = findPredecessor(pre.getNAME(),mOriginal);
		Iterator itPrePreList = preTransformations.iterator();

		while(itPrePreList.hasNext()){
			TRANSFORMATION prePre = (TRANSFORMATION) itPrePreList.next();
			mOriginal = connectTargetToTrans (target,prePre, mOriginal);
		}
		writeToXML(createMapping(tgt, pre, source,mOriginal));

	}

	private static void genGPartialMapping (TRANSFORMATION transformation,MAPPING mOriginal,TARGET originalTgt,FOLDER f,
		TARGET auxTarget,List<TRANSFORMATION> gPredecessorList, GROUP group ){
		
		// SOURCE = prevTrans
		for(TRANSFORMFIELD tf : transformation.getTRANSFORMFIELD()){
			if(group.getNAME().equals(tf.getGROUP())){
				for(CONNECTOR c : mOriginal.getCONNECTOR()){
					if(c.getTOINSTANCE().equals(transformation.getNAME()) && c.getTOFIELD().equals(tf.getNAME())){
						c.setTOINSTANCE(originalTgt.getNAME()+ group.getORDER());
					}
				}
			}
		}
		SOURCE source = targetToSource(auxTarget);
		
		
		f.getTARGET().add(auxTarget);

		f.getSOURCE().add(source);
		
		//List<TRANSFORMATION> preTransformations = findPredecessor(pre.getNAME(),mOriginal);
		Iterator itPrePreList = gPredecessorList.iterator();

		while(itPrePreList.hasNext()){
			TRANSFORMATION prePre = (TRANSFORMATION) itPrePreList.next();
			
			mOriginal = connectTargetGToTrans (auxTarget, prePre, mOriginal, group.getNAME());
						
			writeToXML(createMapping(auxTarget, null, source,mOriginal));
		}
	}


	


	private static POWERMART createMapping(TARGET tgt,TRANSFORMATION pre,SOURCE source,MAPPING mapping){
		MAPPING newMapping = new MAPPING();
		FOLDER newFolder = new FOLDER();
		if(null != pre){
			newMapping = new MAPPING("m_"+ pre.getNAME(),"","1","YES","1");
			newFolder = new FOLDER(pre.getNAME()+"_folder","","NOTSHARED","EVERIS","","rwx---r--",""); //UUID, last param, could be necessary, 55cd59eb-588d-4840-8dee-97c3257a4945
		}
		else{
			newMapping = new MAPPING("m_"+ source.getNAME(),"","1","YES","1");
			 newFolder = new FOLDER(source.getNAME()+"_folder","","NOTSHARED","EVERIS","","rwx---r--",""); //UUID, last param, could be necessary, 55cd59eb-588d-4840-8dee-97c3257a4945
		}
		POWERMART pm = new POWERMART("30-11-2016","1");

		/*
		 * Source
		 */
		newFolder.getSOURCE().add(source);

		/*
		 * Target
		 */
		newFolder.getTARGET().add(tgt);
		/*
		 * Source Qualifier
		 */
		TRANSFORMATION sq = new TRANSFORMATION() ;
		if(null != pre){
			sq = createSQ(pre);	
			newMapping.getTRANSFORMATION().add(sq);
		}else{
			sq = createSQ(source);
			newMapping.getTRANSFORMATION().add(sq);
		}

		/*
		 * Transformation
		 */
		if(null != pre){
			newMapping.getTRANSFORMATION().add(pre);
		}

		/*
		 * Connectors
		 */
		newMapping.getCONNECTOR().addAll(createConnectors(tgt,source,pre,sq,mapping));

		/*
		 *  Instances
		 */
		newMapping.getINSTANCE().addAll(createInstances(tgt,source,pre,sq));

		/*
		 * Targetloadorder
		 */
		TARGETLOADORDER tglo = new TARGETLOADORDER();
		tglo = new TARGETLOADORDER();
		tglo.setORDER("1");
		tglo.setTARGETINSTANCE(tgt.getNAME());
		newMapping.getTARGETLOADORDER().add(tglo);

		/*
		 * No info for the mapping on the following subjects 
		 * NO mappingdependencies
		 * NO erpvalue
		 * NO mappingvariable
		 * NO metadataextension
		 */

		newFolder.getMAPPING().add(newMapping);
		REPOSITORY newRep = new REPOSITORY("NEWREP","DB2","Latin1","1");
		newRep.getFOLDER().add(newFolder);
		pm.getREPOSITORY().add(newRep);

		return pm;

	}



	private static List<TRANSFORMATION> findPredecessor (String name,MAPPING mOriginal){
		List<TRANSFORMATION> tgtPreList = new ArrayList<TRANSFORMATION>();
		for(CONNECTOR c : mOriginal.getCONNECTOR()){
			if(c.getTOINSTANCE().equals(name)){
				for(TRANSFORMATION t : mOriginal.getTRANSFORMATION()){
					if(c.getFROMINSTANCE().equals(t.getNAME()) && !tgtPreList.contains(t)){
						tgtPreList.add(t);
					}
				}
			}
		}
		return tgtPreList;
	}  



	private static TRANSFORMATION findGroupPredecessor (String name,MAPPING mOriginal,String groupFieldName){
		TRANSFORMATION tgtPreList = new TRANSFORMATION();
		for(CONNECTOR c : mOriginal.getCONNECTOR()){
			if(c.getTOFIELD().equals(groupFieldName) && c.getTOINSTANCE().equals(name)){
				for(TRANSFORMATION t : mOriginal.getTRANSFORMATION()){
					if(c.getFROMINSTANCE().equals(t.getNAME()) ){
						return t;
					}
				}
			}
		}
		return null;
	}  
	private static SOURCE createSource (TRANSFORMATION t){
		Integer physicaloffset = 0;
		Integer fieldNumber = 1;
		SOURCE s = new SOURCE();

		if(t.getNAME().startsWith("SQ_"))
			s = new SOURCE(t.getNAME(),"DB2","","","1","OWNERNAME","DB2","1");
		else
			s = new SOURCE("TGT_"+t.getNAME(),"DB2","","","1","OWNERNAME","DB2","1");

		for(TRANSFORMFIELD tf : t.getTRANSFORMFIELD()){
			if(tf.getPORTTYPE().contains("INPUT")){
				/*
				 * SOURCEFIELDS
				 */
				SOURCEFIELD sf = new SOURCEFIELD(tf.getNAME(),"","",tf.getDATATYPE(),"NOT A KEY","10","0","NULL","","0","ELEMITEM","",
						"0","10",Integer.toString(physicaloffset),"10",Integer.toString(fieldNumber),"0","NO");
				physicaloffset = physicaloffset +10;
				fieldNumber ++;
				/*
				 * We convert the datatype if necessary from pwc to DB notation.
				 */
				switch (tf.getDATATYPE()){
				case "string" : sf.setDATATYPE("varchar");
				break;
				case "number" : sf.setDATATYPE("integer");
				sf.setLENGTH("11");
				break;
				case "decimal" : sf.setLENGTH("17");
				sf.setDATATYPE("decimal");
				break;
				case "date/time" : 	sf.setDATATYPE("datetime");
				sf.setLENGTH("29");
				break;
				case "bigint" : sf.setLENGTH("19");
				sf.setDATATYPE("bigint");
				break;
				case "double" : sf.setLENGTH("15");
				sf.setDATATYPE("double");
				break;
				case "binary" : sf.setDATATYPE("integer");
				sf.setLENGTH("19");
				break;
				case "integer" :sf.setDATATYPE("integer");
				sf.setLENGTH("10");
				break;
				case "nstring" :sf.setDATATYPE("varchar");
				break;
				case "real" :sf.setDATATYPE("integer");
				break;
				case "small integer" :sf.setDATATYPE("varchar");
				break;
				case "text" :sf.setDATATYPE("varchar");
				break;
				default: sf.setDATATYPE(tf.getDATATYPE());
				break;
				}

				s.getSOURCEFIELD().add(sf);

			}
		}


		return s;
	}

	private static TRANSFORMATION createSQ (TRANSFORMATION t){
		TRANSFORMATION sq = new TRANSFORMATION("SQ_"+t.getNAME(),"Source Qualifier","1","NO","1");
		TABLEATTRIBUTE ta;

		for(TRANSFORMFIELD tf : t.getTRANSFORMFIELD()){
			if(tf.getPORTTYPE().contains("INPUT")){
				TRANSFORMFIELD tnew = new TRANSFORMFIELD(tf);
				tnew.setPORTTYPE("INPUT/OUTPUT");
				sq.getTRANSFORMFIELD().add(tnew);
			}
		}

		ta = new TABLEATTRIBUTE("SQL Query","");
		sq.getTABLEATTRIBUTE().add(ta);
		ta = new TABLEATTRIBUTE("User Defined Join","");
		sq.getTABLEATTRIBUTE().add(ta);
		ta = new TABLEATTRIBUTE("Source Filter","");
		sq.getTABLEATTRIBUTE().add(ta);
		ta = new TABLEATTRIBUTE("Number Of Sorted Ports","0");
		sq.getTABLEATTRIBUTE().add(ta);
		ta = new TABLEATTRIBUTE("Tracing Level","Normal");
		sq.getTABLEATTRIBUTE().add(ta);
		ta = new TABLEATTRIBUTE("Select Distinct","NO");
		sq.getTABLEATTRIBUTE().add(ta);
		ta = new TABLEATTRIBUTE("Is Partitionable","NO");
		sq.getTABLEATTRIBUTE().add(ta);
		ta = new TABLEATTRIBUTE("Pre SQL","");
		sq.getTABLEATTRIBUTE().add(ta);
		ta = new TABLEATTRIBUTE("Post SQL","");
		sq.getTABLEATTRIBUTE().add(ta);
		ta = new TABLEATTRIBUTE("Output is deterministic","NO");
		sq.getTABLEATTRIBUTE().add(ta);
		ta = new TABLEATTRIBUTE("Output is repeatable","NEVER");
		sq.getTABLEATTRIBUTE().add(ta);

		return sq;
	}
	private static TRANSFORMATION createSQ (SOURCE src){
		TRANSFORMATION sq = new TRANSFORMATION("SQ_"+src.getNAME(),"Source Qualifier","1","NO","1");
		TABLEATTRIBUTE ta;

		for(SOURCEFIELD sf : src.getSOURCEFIELD()){
			TRANSFORMFIELD tnew = new TRANSFORMFIELD(sf.getNAME(),"string","INPUT/OUTPUT",sf.getPRECISION(),sf.getSCALE());
			switch(sf.getDATATYPE()){
			case "varchar" : tnew.setDATATYPE("String");
			break;
			default: tnew.setDATATYPE(sf.getDATATYPE());
			break;

			}
			tnew.setPORTTYPE("INPUT/OUTPUT");
			sq.getTRANSFORMFIELD().add(tnew);

		}

		ta = new TABLEATTRIBUTE("SQL Query","");
		sq.getTABLEATTRIBUTE().add(ta);
		ta = new TABLEATTRIBUTE("User Defined Join","");
		sq.getTABLEATTRIBUTE().add(ta);
		ta = new TABLEATTRIBUTE("Source Filter","");
		sq.getTABLEATTRIBUTE().add(ta);
		ta = new TABLEATTRIBUTE("Number Of Sorted Ports","0");
		sq.getTABLEATTRIBUTE().add(ta);
		ta = new TABLEATTRIBUTE("Tracing Level","Normal");
		sq.getTABLEATTRIBUTE().add(ta);
		ta = new TABLEATTRIBUTE("Select Distinct","NO");
		sq.getTABLEATTRIBUTE().add(ta);
		ta = new TABLEATTRIBUTE("Is Partitionable","NO");
		sq.getTABLEATTRIBUTE().add(ta);
		ta = new TABLEATTRIBUTE("Pre SQL","");
		sq.getTABLEATTRIBUTE().add(ta);
		ta = new TABLEATTRIBUTE("Post SQL","");
		sq.getTABLEATTRIBUTE().add(ta);
		ta = new TABLEATTRIBUTE("Output is deterministic","NO");
		sq.getTABLEATTRIBUTE().add(ta);
		ta = new TABLEATTRIBUTE("Output is repeatable","NEVER");
		sq.getTABLEATTRIBUTE().add(ta);

		return sq;
	}
	private static TRANSFORMATION unionToEXP(TRANSFORMATION t){
		TRANSFORMATION exp = new TRANSFORMATION("EXP_"+t.getNAME(),"Expression","1","NO","1");

		for(TRANSFORMFIELD tf : t.getTRANSFORMFIELD()){
			if(tf.getPORTTYPE().equals("OUTPUT")){
				tf.setPORTTYPE("INPUT/OUTPUT");
				exp.getTRANSFORMFIELD().add(tf);
			}
		}

		return exp;
	}

	private static ArrayList<TRANSFORMATION> routerToFLT (TRANSFORMATION t, ArrayList<TRANSFORMFIELD> tfs, ArrayList<String> groups){
		for(String s : groups){
			TRANSFORMATION flt = new TRANSFORMATION("FLT_"+s+"_"+t.getNAME(),"Filter","1","NO","1");
			flt.getTRANSFORMFIELD().addAll(tfs);
		}



		return null;
	}

	private static SOURCE targetToSource(TARGET t){
		SOURCE s = new SOURCE(t.getNAME(),"DB2","","","1","OWNERNAME","DB2","1");

		int physicaloffset = 0;
		int fieldnumber = 0;
		for(TARGETFIELD tf : t.getTARGETFIELD()){
			fieldnumber++;
			SOURCEFIELD sf = new SOURCEFIELD(tf.getNAME(),tf.getBUSINESSNAME(),tf.getDESCRIPTION(),tf.getDATATYPE(),tf.getKEYTYPE(),tf.getPRECISION(),
					tf.getSCALE(),tf.getNULLABLE(),"","","ELEMITEM","","0",tf.getPRECISION(),Integer.toString(physicaloffset),tf.getPRECISION(),
					Integer.toString(fieldnumber),"0","NO");
			physicaloffset = physicaloffset + Integer.parseInt(tf.getPRECISION());

			s.getSOURCEFIELD().add(sf);
		}


		return s;

	}

	private static TARGET sourceToTarget(SOURCE s){
		TARGET t = new TARGET(s.getNAME(),"1","DB2","1");

		int physicaloffset = 0;
		int fieldnumber = 0;
		for(SOURCEFIELD sf : s.getSOURCEFIELD()){
			TARGETFIELD tf = new TARGETFIELD(sf.getNAME(),sf.getDATATYPE(),sf.getKEYTYPE(),sf.getPRECISION(),sf.getSCALE(),sf.getNULLABLE(),sf.getFIELDNUMBER());
			t.getTARGETFIELD().add(tf);
		}	
		return t;
	}

	private static MAPPING connectTargetToTrans(TARGET t, TRANSFORMATION pre, MAPPING oriM){
		MAPPING m = oriM;
		List<CONNECTOR> conns = new ArrayList<CONNECTOR>();
		List<TRANSFORMATION> transformations = new ArrayList<TRANSFORMATION>();
		for(CONNECTOR c : m.getCONNECTOR()){
			if(c.getFROMINSTANCE().equals(pre.getNAME()) && t.getNAME().equals("TGT_"+c.getTOINSTANCE())){
				c.setTOINSTANCE(t.getNAME());
			}


			//			if(c.getTOINSTANCE().equals(t.getNAME())){
			//				for(TRANSFORMFIELD tf : pre.getTRANSFORMFIELD()){
			//					if(c.getTOFIELD().equals(tf.getNAME())){
			//						c.setTOINSTANCE(t.getNAME());
			//					}
			//				}
			//			}
			//			conns.add(c);
		}
		//m.getCONNECTOR().clear();
		//m.getCONNECTOR().addAll(conns);



		m.getINSTANCE().add(new INSTANCE(t.getNAME(),"Target Instance","NO","TARGET",t.getNAME()));


		return m;
	}

	
	
	private static MAPPING connectTargetGToTrans(TARGET t, TRANSFORMATION pre, MAPPING oriM,String numGroup){
		
		MAPPING m = oriM;
		List<CONNECTOR> conns = new ArrayList<CONNECTOR>();
		List<TRANSFORMATION> transformations = new ArrayList<TRANSFORMATION>();
		for(CONNECTOR c : m.getCONNECTOR()){
			if(c.getFROMINSTANCE().equals(pre.getNAME()) && t.getNAME().equals("TGT_"+c.getTOINSTANCE()+numGroup)){
				c.setTOINSTANCE(t.getNAME());
			}


			//			if(c.getTOINSTANCE().equals(t.getNAME())){
			//				for(TRANSFORMFIELD tf : pre.getTRANSFORMFIELD()){
			//					if(c.getTOFIELD().equals(tf.getNAME())){
			//						c.setTOINSTANCE(t.getNAME());
			//					}
			//				}
			//			}
			//			conns.add(c);
		}
		//m.getCONNECTOR().clear();
		//m.getCONNECTOR().addAll(conns);



		m.getINSTANCE().add(new INSTANCE(t.getNAME(),"Target Instance","NO","TARGET",t.getNAME()));


		return m;
		
		
	}
	
	
	private static ArrayList<CONNECTOR> createConnectors (TARGET tgt,SOURCE src, TRANSFORMATION trns, TRANSFORMATION sq,MAPPING mapping){
		ArrayList<CONNECTOR> conns = new ArrayList<CONNECTOR>();
		if(null != trns){
			TRANSFORMATION t = trns;
			for(TRANSFORMFIELD tf : t.getTRANSFORMFIELD()){

				if(tf.getPORTTYPE().equals("INPUT")){
					conns.add(new CONNECTOR(tf.getNAME(),src.getNAME(),"Source Definition","Source Qualifier","SQ_"+t.getNAME(),tf.getNAME()));
					conns.add(new CONNECTOR(tf.getNAME(),"SQ_"+t.getNAME(),"Source Qualifier",t.getTYPE(),t.getNAME(),tf.getNAME()));	
				}else if(tf.getPORTTYPE().equals("OUTPUT")){
					for(CONNECTOR c : mapping.getCONNECTOR()){
						if(c.getFROMINSTANCE().equals(t.getNAME()) && c.getTOINSTANCE().equals(tgt.getNAME())){
							c.setTOINSTANCETYPE("Target Definition");
							conns.add(c);
						}
					}
				}else if(tf.getPORTTYPE().contains("INPUT/OUTPUT")){
					conns.add(new CONNECTOR(tf.getNAME(),src.getNAME(),"Source Definition","Source Qualifier","SQ_"+t.getNAME(),tf.getNAME()));
					conns.add(new CONNECTOR(tf.getNAME(),"SQ_"+t.getNAME(),"Source Qualifier",t.getTYPE(),t.getNAME(),tf.getNAME()));
					conns.add(new CONNECTOR(tf.getNAME(),t.getNAME(),t.getTYPE(),"Target Definition",tgt.getNAME(),tf.getNAME()));	
				}
			}
		}else{
			for(TRANSFORMFIELD tf : sq.getTRANSFORMFIELD()){
				conns.add(new CONNECTOR(tf.getNAME(),src.getNAME(),"Source Definition","Source Qualifier",sq.getNAME(),tf.getNAME()));
				conns.add(new CONNECTOR(tf.getNAME(),sq.getNAME(),"Source Qualifier","Target Definition",tgt.getNAME(),tf.getNAME()));
			}
		}
		return conns;
	}

	private static ArrayList<INSTANCE> createInstances(TARGET tgt, SOURCE src, TRANSFORMATION trns, TRANSFORMATION sq){
		ArrayList<INSTANCE> instances = new ArrayList<INSTANCE>();

		INSTANCE insrc = new INSTANCE(src.getNAME(),"SOURCE","NO","Source Definition",src.getNAME());
		insrc.setDBDNAME("DB2");
		instances.add(insrc);
		instances.add(new INSTANCE(tgt.getNAME(),"TARGET","NO","Target Definition",tgt.getNAME()));
		if(null != trns)
			instances.add(new INSTANCE(trns.getNAME(),"TRANSFORMATION","NO",trns.getTYPE(),trns.getNAME()));
		INSTANCE insq = new INSTANCE(sq.getNAME(),"TRANSFORMATION","NO",sq.getTYPE(),sq.getNAME());
		ASSOCIATEDSOURCEINSTANCE aso = new ASSOCIATEDSOURCEINSTANCE(src.getNAME());
		insq.getASSOCIATEDSOURCEINSTANCE().add(aso);
		instances.add(insq);

		return instances;
	}


	/*
	 * 	This function converts the POWERMART-object to XML using the JAXB-library
	 * 
	 * 	@param	pwM	The object we want to convert to XML.
	 */

	public static void writeToXML(POWERMART pwM){
		try{
			File file = new File(outputPath+"/xml/"+ pwM.getREPOSITORY().get(0).getFOLDER().get(0).getMAPPING().get(0).getNAME() +".XML");
			JAXBContext jaxbContext = JAXBContext.newInstance(POWERMART.class);
			Marshaller jaxbMarshaller = jaxbContext.createMarshaller();


			jaxbMarshaller.setProperty(Marshaller.JAXB_ENCODING,"ISO-8859-1");
			jaxbMarshaller.setProperty("com.sun.xml.bind.xmlHeaders", "<!DOCTYPE POWERMART SYSTEM \"powrmart.dtd\">\n");
			if(bformat){jaxbMarshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT,true);}
			jaxbMarshaller.marshal(pwM,file);
			//jaxbMarshaller.marshal(pwM,System.out);

		}catch(JAXBException e){
			Main.writeError(e);
		}

	}

	private static MAPPING unionToExp(MAPPING mapping){
		ArrayList<CONNECTOR> connectors = new ArrayList<CONNECTOR>();
		ArrayList<TRANSFORMATION> transformations = new ArrayList<TRANSFORMATION>();

		for(CONNECTOR c : mapping.getCONNECTOR()){
			connectors.add(c);
		}
		for(TRANSFORMATION t : mapping.getTRANSFORMATION()){
			transformations.add(t);
		}
		for(TRANSFORMATION transformation : transformations){
			if("Union Transformation".equals(transformation.getTEMPLATENAME())){
				for(GROUP group : transformation.getGROUP()){
					if(!group.getNAME().equals("OUTPUT")){
						TRANSFORMATION expression = new TRANSFORMATION("EXP_UN_"+group.getNAME(),"Expression","1","NO","1");
						for(TRANSFORMFIELD tf : transformation.getTRANSFORMFIELD()){
							TRANSFORMFIELD newTF = new TRANSFORMFIELD(tf);
							newTF.setPORTTYPE("INPUT/OUTPUT");

							for(CONNECTOR connector : connectors){
								if(connector.getTOINSTANCE().equals(transformation.getNAME()) && connector.getTOFIELD().equals(tf.getNAME())){
									CONNECTOR newConn = new CONNECTOR(connector.getTOFIELD().substring(0, connector.getTOFIELD().length() - group.getORDER().length()),expression.getNAME(),"Expression","","","");
									for(CONNECTOR targetconnector : mapping.getCONNECTOR()){
										if(targetconnector.getFROMINSTANCE().equals(transformation.getNAME()) && targetconnector.getFROMFIELD().equals(tf.getNAME())){
											newConn.setTOFIELD(targetconnector.getTOFIELD());
											newConn.setTOINSTANCE(targetconnector.getTOINSTANCE());
											newConn.setTOINSTANCETYPE(targetconnector.getFROMINSTANCETYPE());
										}
									}
									connector.setTOINSTANCE(expression.getNAME());
									connector.setTOFIELD(connector.getTOFIELD().substring(0, connector.getTOFIELD().length() - group.getORDER().length()));
									mapping.getCONNECTOR().add(newConn);
								}
							}
							newTF.setNAME(tf.getNAME().substring(0, tf.getNAME().length() - group.getORDER().length()));
							expression.getTRANSFORMFIELD().add(newTF);
						}
						INSTANCE expInst = new INSTANCE(expression.getNAME(),"TRANSFORMATION","NO","Expression",expression.getNAME());
						mapping.getINSTANCE().add(expInst);
						mapping.getTRANSFORMATION().add(expression);
					}
				}
			}
		}
		return mapping;
	}

	private static TRANSFORMATION findTransformfieldSource(TRANSFORMFIELD transformfield, TRANSFORMATION transformation, MAPPING mapping){
		for(CONNECTOR connector : mapping.getCONNECTOR()){
			if(connector.getTOINSTANCE().equals(transformation.getNAME()) && connector.getTOFIELD().equals(transformfield.getNAME())){
				for(TRANSFORMATION sourceTransformation : mapping.getTRANSFORMATION()){
					if(sourceTransformation.getNAME().equals(connector.getFROMINSTANCE())){
						return sourceTransformation;
					}
				}
			}
		}
		return null;
	}


}



//if(t.getTEMPLATENAME().equals("Union Transformation")){
//	/*
//	 * Union --> change the union transformation to a expression transformation.
//	 */
//	t = unionToEXP(t);
//}else if(t.getTYPE().equals("Router")){
//	/*
//	 * Router --> create a new filter for each routing group.
//	 */
//	ArrayList<String> groups = new ArrayList<String>();
//	ArrayList<TRANSFORMFIELD> tfs = new ArrayList<TRANSFORMFIELD>();
//	ArrayList<TRANSFORMATION> trnstgt = new ArrayList<TRANSFORMATION>();
//	TABLEATTRIBUTE taFC = new TABLEATTRIBUTE();
//
//	/*
//	 * Get all the groupnames, and inputfields.
//	 */
//	for(TRANSFORMFIELD tf : t.getTRANSFORMFIELD()){
//		if(tf.getPORTTYPE().equals("INPUT")){
//			tf.setPORTTYPE("INPUT/OUTPUT");
//			tfs.add(tf);
//		}else if(!groups.contains(tf.getGROUP())){
//			groups.add(tf.getGROUP());
//		}
//	}
//	/*
//	 * For loop over the groupnames. 
//	 */
//	int groupI = 0;
//	for(GROUP g : t.getGROUP()){
//		groupI ++;
//		/*
//		 * We create a filter transformation.
//		 */
//		TRANSFORMATION flt = new TRANSFORMATION("FLT_"+g.getNAME()+"_"+t.getNAME(),"Filter","1","NO","1");
//		/*
//		 * We add the transformationfields from the router that were input.
//		 */
//		flt.getTRANSFORMFIELD().addAll(tfs);
//		/*
//		 * We look for the orginal target using the connectors. 
//		 */
//		for(CONNECTOR c : m.getCONNECTOR()){
//			for(TRANSFORMFIELD tf : tfs){
//				if(c.getFROMFIELD().equals(tf.getNAME()+groupI)){
//					for(TRANSFORMATION trns : m.getTRANSFORMATION()){
//						if(c.getTOINSTANCE().equals(trns.getNAME()) && !trnstgt.contains(trns)){
//							trnstgt.add(trns);
//						}
//					}
//				}
//			}
//		}
//		
//		TARGET newTgt = new TARGET(trnstgt.get(0).getNAME(),"1","DB2","1");
//		int fieldnumber = 0;
//		for(TRANSFORMFIELD tf : tfs){
//			fieldnumber ++;
//			TARGETFIELD tgtf = new TARGETFIELD(tf.getNAME(),tf.getDATATYPE(),"NOT A KEY",tf.getPRECISION(),tf.getSCALE(),"NULL",Integer.toString(fieldnumber));
//			switch (tf.getDATATYPE()){
//			case "string" : tgtf.setDATATYPE("varchar");
//			break;
//			case "number" : tgtf.setDATATYPE("integer");
//			break;
//			case "date/time" : 	tgtf.setDATATYPE("datetime");
//			break;
//			case "binary" : tgtf.setDATATYPE("integer");
//			break;
//			case "integer" :tgtf.setDATATYPE("integer");
//			break;
//			case "nstring" :tgtf.setDATATYPE("varchar");
//			break;
//			case "real" :tgtf.setDATATYPE("integer");
//			break;
//			case "small integer" :tgtf.setDATATYPE("varchar");
//			break;
//			case "text" :tgtf.setDATATYPE("varchar");
//			break;
//			default: tgtf.setDATATYPE(tf.getDATATYPE());
//			break;
//			}
//			newTgt.getTARGETFIELD().add(tgtf);
//		}
//
//		if(g.getEXPRESSION()!=null){
//			taFC.setVALUE(g.getEXPRESSION());
//		}else if(taFC.getVALUE() != null && !g.getNAME().equals("INPUT")){
//			taFC.setVALUE(taFC.getVALUE()+" AND NOT("+g.getEXPRESSION()+")");
//		}else if(!g.getNAME().equals("INPUT")){
//			taFC.setVALUE("NOT("+g.getEXPRESSION()+")");
//		}
//		taFC.setNAME("Filter Condition");
//		TABLEATTRIBUTE taTL = new TABLEATTRIBUTE("Tracing Level","Normal");
//		t.getTABLEATTRIBUTE().add(taTL);
//		t.getTABLEATTRIBUTE().add(taFC);
//		
//	}
//}
